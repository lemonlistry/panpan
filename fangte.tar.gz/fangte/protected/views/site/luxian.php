<div class="mid">
	<!--左边-->
    <?php include dirname('index.php') . '/protected/views/left.php';?>
  <div class="mid_right_nr">
  	<div class="mbx">
  		<span>您所在的位置：<a href="/" title="株洲方特欢乐世界">首页</a> > 株洲方特欢乐世界交通线路</span>
  	</div>
  	<div class="title">
    	<h1>株洲方特欢乐世界交通线路</h1>
    </div>
    <div class="nr"><p class="fwb blue mb5" style="text-align: center"><span style="font-size: 16px"><img alt="" width="600" height="499" src="/uploadfile/2012030713113073499.jpg" /></span></p>
<p class="fwb blue mb5">&nbsp;</p>
<p class="fwb blue mb5"><span style="color: #339966"><strong><span style="font-size: 16px">公交线路：</span></strong></span></p>
<p class="ti2e lh25 mb10"><span style="font-size: 16px">株洲市区&ldquo;<span style="color: #ff6600"><span class="cF30">钻石路</span></span>&rdquo;站上车，乘坐云田专线在&ldquo;<span style="color: #ff6600"><span class="cF30">云田</span></span>&rdquo;站下车，往北前行<span class="cF30">300米</span>左右即可到达</span></p>
<p class="ti2e lh25 mb10"><span style="font-size: 16px">株洲市区&ldquo;<span style="color: #ff6600"><span class="cF30">车站西路</span></span>&rdquo;站上车，乘坐<span style="color: #ff6600"><span class="cF30">T6路</span></span>公交车至终点站<a href="http://fangte.8090goto.com/site/Route">株洲方特欢乐世界</a></span>&nbsp;</p>
<p class="fwb blue mb5"><span style="color: #339966"><strong><span style="font-size: 16px">高速通道：</span></strong></span></p>
<p class="ti2e lh25 mb10"><span style="font-size: 16px">你可以走长株潭高速在&ldquo;<span style="color: #ff6600"><span class="cF30">云龙新城</span></span>&rdquo;出口下，根据指示牌指示方向，前行大约<span style="color: #ff6600"><span class="cF30">700米</span></span>，即可到达目的地。</span></p>
<p class="ti2e lh25 mb10"><span style="color: #339966"><strong><span style="font-size: 16px">外地游客前往路线：</span></strong></span></p>
<p class="ti2e lh25 mb10"><span style="font-size: 16px">1.衡阳、郴州等地出发，经<span style="color: #ff6600"><span class="cF30">京港澳高速</span></span>、<span style="color: #ff6600"><span class="cF30">沪昆高速</span></span>，<span style="color: #ff6600">转<span class="cF30">长株高速</span></span>至&ldquo;<span style="color: #ff6600"><span class="cF30">云龙新城</span></span>&rdquo;出口下。</span></p>
<p class="ti2e lh25 mb10"><span style="font-size: 16px">2.岳阳等地出发，经<span style="color: #ff6600"><span class="cF30">京港澳高速</span></span>、<span style="color: #ff6600"><span class="cF30">长浏高速</span></span>，转<span style="color: #ff6600"><span class="cF30">长株高速</span></span>至&ldquo;<span style="color: #ff6600"><span class="cF30">云龙新城</span></span>&rdquo;出口下。</span></p>
<p class="ti2e lh25 mb10"><span style="font-size: 16px">3.江西等地出发，经<span style="color: #ff6600"><span class="cF30">沪昆高速</span></span>，转<span style="color: #ff6600"><span class="cF30">长株高速</span></span>至&ldquo;<span style="color: #ff6600"><span class="cF30">云龙新城</span></span>&rdquo;出口下。</span></p>
<p class="ti2e lh25 mb10"><span style="font-size: 16px">4.怀化等地出发，经<span style="color: #ff6600"><span class="cF30">沪昆高速</span></span>，转<span style="color: #ff6600"><span class="cF30">长株高速</span></span>至&ldquo;<span style="color: #ff6600"><span class="cF30">云龙新城</span></span>&rdquo;出口下。</span></p>
<p class="ti2e lh25 mb10"><span style="font-size: 16px">5.常德、益阳等地出发，经<span style="color: #ff6600"><span class="cF30">长常高速</span></span>、<span style="color: #ff6600"><span class="cF30">长沙绕城高速</span></span>，转<span style="color: #ff6600"><span class="cF30">长株高速</span></span>至&ldquo;<span style="color: #ff6600"><span class="cF30">云龙新城</span></span>&rdquo;出口下。</span></p>
<img src='<?php Yii::app()->request->baseUrl?>/images/luxian.jpg'>
</div>
    <div class="nr_bottom"></div>
  </div>
</div>
<div class="clear"></div>
