
<DIV class=mid><!--左边-->
 <?php include dirname('index.php') . '/protected/views/left.php';?>
<DIV class=mid_right_nr>
<DIV class=mbx><SPAN>您所在的位置：<A title=株洲方特欢乐世界 href="/">首页</A> &gt; 
株洲方特欢乐世界游玩须知</SPAN> </DIV>
<DIV class=title>
<H1>株洲方特欢乐世界游玩须知</H1></DIV>
<DIV class=nr>
<P><STRONG><SPAN style="FONT-SIZE: 16px">1、</SPAN></STRONG><SPAN 
style="FONT-SIZE: 16px">直通车门票说明：</SPAN></P>
<P><SPAN style="FONT-SIZE: 16px">&nbsp;&nbsp;&nbsp; 
<STRONG>包含：</STRONG>方特门票+株洲到方特车（30分钟车程）；</SPAN></P>
<P><SPAN style="FONT-SIZE: 16px">&nbsp;&nbsp;&nbsp;<STRONG> 
接客地点：</STRONG>株洲火车站附近广场家润多；</SPAN></P>
<P><SPAN style="FONT-SIZE: 16px">&nbsp;&nbsp;&nbsp; <STRONG>接客时间：</STRONG>周一至周五 
8：30；</SPAN></P>
<P><SPAN style="FONT-SIZE: 16px">&nbsp;&nbsp;&nbsp; 
<STRONG>直通车小孩票要求：</STRONG>1.2M-1.4M；</SPAN></P>
<P><SPAN style="FONT-SIZE: 16px"><STRONG>2、</STRONG><A 
href="http://fangte.8090goto.com/site/notes">株洲方特欢乐世界</A>景区门票类型：通票；</SPAN></P>
<P><STRONG><SPAN style="FONT-SIZE: 16px">3、</SPAN></STRONG><SPAN 
style="FONT-SIZE: 16px">取票：提前电话工作人员至景区门口取票；</SPAN></P>
<P><STRONG><SPAN style="FONT-SIZE: 16px">4、</SPAN></STRONG><SPAN 
style="FONT-SIZE: 16px">特殊门票：</SPAN></P>
<P><SPAN style="FONT-SIZE: 16px">&nbsp;&nbsp;&nbsp; 
儿童票：1.2米以下免票，1.2M-1.4M儿童购买儿童票，票价150元/人；<BR>&nbsp;&nbsp;&nbsp; 
老人票：70岁老人持本人老人证加身份证免费入园；<BR>&nbsp;&nbsp;&nbsp; 学生票：10以上学生统一校服享受学生优惠；</SPAN></P>
<P><STRONG><SPAN style="FONT-SIZE: 16px">5、</SPAN></STRONG><SPAN 
style="FONT-SIZE: 16px">景区开放时间：平时9：30-17：30&nbsp; 周末节假日：9：00-18：00；</SPAN></P>
<P><STRONG><SPAN style="FONT-SIZE: 16px">6、</SPAN></STRONG><SPAN 
style="FONT-SIZE: 16px">停车：4小时免费，4-8小时收费5元/辆；</SPAN></P>
<P><STRONG><SPAN style="FONT-SIZE: 16px">7、</SPAN></STRONG><SPAN 
style="FONT-SIZE: 16px">网上预订不提供发票；</SPAN><SPAN 
style="FONT-SIZE: 16px"><BR></SPAN>&nbsp;</P></DIV>
<DIV class=nr_bottom></DIV></DIV></DIV>
<DIV class=clear></DIV>

