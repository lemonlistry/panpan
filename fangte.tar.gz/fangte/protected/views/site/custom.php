
<!--订票-->
<div class="mid">
	<!--左边-->
     <?php include dirname('index.php') . '/protected/views/left.php';?>
  <div class="mid_right_nr">
  	<div class="mbx">
  		<span>您所在的位置：<a href="/" title="株洲方特欢乐世界">首页</a> > 株洲方特欢乐世界简介</span>
  	</div>
  	<div class="title">
    	<h1>株洲方特欢乐世界简介</h1>
    </div>
    <div class="nr"><div style="line-height: 30px">
<p><span style="font-size: 16px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 株洲方特欢乐世界位于株洲云龙示范区，地处长株潭城市群中心，占地60万平方米，总投资25亿元，是一个国际一流的第四代主题公园。公园以科幻和动漫为最大特色，可与当前西方最先进的主题公园相媲美。</span></p>
<p><span style="font-size: 16px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 株洲方特欢乐世界由飞越极限、星际航班、恐龙危机、生命之光、海螺湾、逃出恐龙岛、维苏威火山、聊斋、宇宙博览会、火流星、探险乐园等十几个主题项目区组成，包含主题项目、游乐项目、休闲景观项目以及配套服务共计200多项，绝大多数项目老少皆宜。这里有国际一流的高空飞翔体验项目&ldquo;飞越极限&rdquo;，大型动感太空飞行体验项目&ldquo;星际航班&rdquo;，大型火山探险项目&ldquo;维苏威火山&rdquo;，大型恐龙复活灾难体验项目&ldquo;恐龙危机&rdquo;，大型主题漂流&ldquo;逃出恐龙岛&rdquo;，让人琢磨不透的中国传统神话的神奇演绎 &ldquo;聊斋&rdquo;，色彩斑斓如梦似幻的&ldquo;海螺湾&rdquo;&hellip;&hellip;对于喜欢刺激的朋友，我们的探险乐园里有大摆锤、波浪翻滚、勇敢者转盘、探空飞梭等大量让人尖叫的大中型机械类体验项目。 </span></p>
<p><strong><span style="font-size: 16px">株洲方特欢乐世界游乐项目</span></strong></p>
<p><span style="color: #0000ff"><strong><span style="font-size: 16px">恐龙危机</span><span style="font-size: 16px"><br />
</span></strong></span><span style="font-size: 16px">　　游客乘坐游览车在一个恐龙横行、一片混乱的城市中穿行，经过17处精心设计、虚实结合的场景，经历一场恐龙破坏、毁灭城市的浩劫。</span></p>
<p><span style="font-size: 16px">　　项目充分利用了现场实景、动感平台，综合了多自由度动感游览车、现场特技和巨幕、环幕4D电影等多项高科技技术，将立体影像与真实场景结合，极大地拓展了视觉空间，给游客强烈的震撼感和强烈的参与感、真实感，仿佛真的在大厦间飞驰，经历一场场惊心动魄的战斗。</span></p>
<p><strong><span style="color: #0000ff"><span style="font-size: 16px">逃出恐龙岛</span><span style="font-size: 16px"><br />
</span></span></strong><span style="font-size: 16px">　　&ldquo;逃出恐龙岛&rdquo;项目是一个结合Darkride（黑暗之旅）、漂流、激流勇进为一体的大型项目。由特种装饰和现场特技装置模拟出真实的恐龙岛场景，让游客们置身一个被恐龙侵占的原始部落岛屿。游客将乘船漂流，在一系列险象环生的经历之后，从高空冲下，体验高空滑坠的刺激感受，成功逃离恐龙的追捕。项目分排队区、表演区两个部分。</span></p>
<p><strong><span style="color: #0000ff"><span style="font-size: 16px">飞越极限</span><span style="font-size: 16px"><br />
</span></span></strong><span style="font-size: 16px">　　&ldquo;飞越极限&rdquo;项目占地面积约2100平方米。项目以人类航空发展历史引入，通过陈列实体模型、图片与视频等展项，向游客立体展示人类追求飞行梦想的每一寸历史足迹。随后游客将通过观赏球幕电影体验自由飞翔的真实感觉。</span></p>
<p><strong><span style="color: #0000ff"><span style="font-size: 16px">嘟比历险</span><span style="font-size: 16px"><br />
</span></span></strong><span style="font-size: 16px">　　本项目将动画片&ldquo;小鸡不好惹&rdquo;的故事延续出来，瘦高高和胖乎乎两只黄鼠狼还没有放弃抓鸡吃，他们屡战屡败，屡败屡战，发誓要吃上全鸡餐，不过这一次小鸡们不再孤军奋战，它们有了游客的帮助。游客通过七轮新奇有趣的射击游戏来帮助小鸡，破坏黄鼠狼的进攻，取得这场快乐农庄大战的最后胜利。项目分为预演厅和主演厅两个部分。</span></p>
<p><strong><span style="color: #0000ff"><span style="font-size: 16px">十二生肖快乐街<br />
</span></span></strong><span style="font-size: 16px">　　&ldquo;嘟比脱口秀之十二生肖快乐街&rdquo;是以动画片《快乐街》为题材，与现场观众相结合的交互影像剧场项目。项目占地面积约600平方米，可容纳90人左右。共分为候场厅、主演厅两部分。观众在候场区观看动画片《十二生肖快乐街》等候入场。主演厅为交互影像剧场，通过三台电视机和一个大型互动投影，有趣的故事情节，生动有趣的交互，在虚拟嘟比的带领下体验互动影像剧场的乐趣。</span></p>
<p><strong><span style="color: #0000ff"><span style="font-size: 16px">方特卡通城堡<br />
</span></span></strong><span style="font-size: 16px">　　&ldquo;方特卡通城堡&rdquo;项目是一个展示卡通制作流程，介绍动漫创作方法，展现卡通相关衍生产品的卡通大百科项目。在这里，游客不仅可以全面了解卡通文化，还能与卡通角色亲密互动，乐趣无穷。卡通城堡内分&ldquo;卡通秀秀场&rdquo;、&ldquo;卡通展示区&rdquo;、&ldquo;动漫工作室&rdquo;、&ldquo;卡通教室&rdquo;四部分。</span></p>
<p><strong><span style="color: #0000ff"><span style="font-size: 16px">海螺湾<br />
</span></span></strong><span style="font-size: 16px">　　环幕4D电影，蔚蓝色的海洋世界里，鱼儿们快乐的生活，它们之间发生着十分有趣的故事，观众将戴上立体眼镜，透过极富现场感的特技，来感受可爱的海洋生物们带来的一幕幕啼笑皆非的场面。项目占地约2800平方米，可同时容纳600人体验。</span></p>
<p><strong><span style="color: #0000ff"><span style="font-size: 16px">影视特技摄影棚<br />
</span></span></strong><span style="font-size: 16px">　　&ldquo;影视特技摄影棚&rdquo;是一个体验类项目，影片在摄制时，游客们进片场参观，工作人员会热心向游客们揭秘影视拍摄的幕后制作。导演需要一些群众演员参与演出时，工作人员会从游客当中挑选几个群众演员饰演剧中角色。在拍摄过程中，饰演群众演员的游客们不但可以过一把演员瘾，还将体验到影视制作的高新科技手段，幽默逗趣的事件穿插其中，参观的游客乐不可支</span>。</p>
</div></div>
    <div class="nr_bottom"></div>
  </div>
</div>
<div class="clear"></div>
