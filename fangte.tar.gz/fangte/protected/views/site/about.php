
<DIV class=mid><!--左边-->
<?php include dirname('index.php') . '/protected/views/left.php';?>
<DIV class=mid_right_nr>
<DIV class=mbx><SPAN>您所在的位置：<A title=株洲方特欢乐世界 href="<?php echo $this->createUrl('site/index')?>">首页</A> &gt; 
株洲方特欢乐世界联系方式</SPAN> </DIV>
<DIV class=title>
<H1>株洲方特欢乐世界联系方式</H1></DIV>
<DIV class=nr>
<P><SPAN style="FONT-SIZE: 16px">联系人：株洲方特欢乐世界直通车</SPAN></P>
<P><SPAN style="FONT-SIZE: 16px">电话：0731-28827739</SPAN></P>
<P><SPAN style="FONT-SIZE: 16px">手机：18932137505</SPAN></P>
<P><SPAN style="FONT-SIZE: 16px">传真：0731-<SPAN 
style="FONT-FAMILY: Arial, Helvetica, sans-serif" 
class=Apple-style-span>28820078</SPAN></SPAN></P>
<P><SPAN style="FONT-SIZE: 16px">QQ： &nbsp;1335658572</SPAN></P>
<P><SPAN style="FONT-SIZE: 16px">邮箱：1790039630@QQ.COM</SPAN></P>
<P><SPAN style="FONT-SIZE: 16px">株洲方特欢乐世界<A>：</A><A 
href="http://fangte.8090goto.com">http://fangte.8090goto.com</A></SPAN></P>
<P><SPAN style="FONT-SIZE: 16px">地址：湖南省株洲市中心广场家润多B栋1818室</SPAN></P></DIV>
<DIV class=nr_bottom></DIV></DIV></DIV>
<DIV class=clear></DIV>
